package com.example.academiaapp

data class Workout(
    var id: Long = 0,
    var name: String,
    var description: String
)